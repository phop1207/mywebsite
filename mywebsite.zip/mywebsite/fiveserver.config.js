module.exports = {
    php: "C:\\xampp\\php\\php.exe"  // ตรวจสอบให้แน่ใจว่า path ถูกต้อง
  };  